#include <iostream>
#include <iostream>
#include<ctime>
#include<cstdlib>
#include<string>
using namespace std; 

//function declaration
//---------------game functions--------------------
string inventory[5];
char input;

//----------------player spasific------------------
bool isDead = false;
bool hasWon = false;
bool giveup = false;
//----------------cop spasific---------------------
char cop();
int badge = false;
bool copdead = false;

//---------------ending choices--------------------
int devilswork = 0;
int dead = 0;
int sinners = 0;
int nothanks = 0;
int thedevil = 0;


//--------------------------------------game loop--------------------------------------
int main() {
    string input = "start";


    srand(time(NULL));
    //intro gose here

    while (input.compare("quit") != 0 && isDead == false && hasWon == false && giveup == false)



  
    string input = "cop";
    char room = 'n';

    while (input.compare("e") != 0) {

        switch (room) {
        case 'n':
            // level one----------------------------
            getline(cin, input);
            if (input.compare("a") == 0)
                room = 'a';
                //fight 

            else if (input.compare("b") == 0)
                room = 'b';
                //item
                
            else if (input.compare("c") == 0)
                room = 'c';
                //talk

            else if (input.compare("d") == 0)
                room = 'd';
                //investigate

            else if (input.compare("e") == 0)
                room = 'e';
                //give up

            else {
                cout << "sorry, I don't understand" << endl;

                getline(cin, input);
                room = 'n';
            }
            break;

        case 'a':
            //---------------------------fight-----------------------------------
            getline(cin, input);
            if (input.compare("n") == 0)
                room = 'n';

            else
                cout << "sorry, I don't understand" << endl;
            break;

        case 'b':
            //---------------------------item--------------------------------------

            if (badge == false) {
                //normal fight this is not an option
                getline(cin, input);
               if (input.compare("n") == 0)
                  room = 'n';
            }

            if (badge == true) {
              // seacret fight

              // you pull out the badge he asks you where you got it
              // you tell him you found it and you ask him why he cares about it
              //he tells you his story
              //you are given the same choice kill hi or spare him 
              getline(cin, input);
              if (input.compare("y") == 0)
                room = 'u';
              if (input.compare("n") == 0)
                room = 'w';

                

            }



            getline(cin, input);
            if (input.compare("n") == 0)
                room = 'n';
            
            else
                cout << "sorry, I don't understand" << endl;
            break;

        case 'c':
            //---------------------------talk-----------------------------------
            
            
            //-----talk string------
            string input = "cop";
            char room = 'c';

            while (input.compare("e") != 0) {

            switch (room) {
             case 'c':
             //the normal options cahange to talk options they are labeled a b c and d. the text will despaly what each is when they select on it will tkae them to the corosponding room.


             getline(cin, input);
             //ask why he didnt conpleat the deal
               if (input.compare("a") == 0)
                room = 'v';
             //ask why he made the deal
               if (input.compare("b") == 0 && badge == true)
                room = 'x';
                else 
                cout<<"sorry you cant do that"<<endl;
             //ask about badge
               if (input.compare("c") == 0)
                room = 'y';
             //tell him to die allredy
               if (input.compare("d") == 0)
                room = 'z';

              else
                cout << "sorry, I don't understand" << endl;
             break;

             case 'v':
             //he didnt conplet the deal becuse he couldnt go trough with it he had allready killed one inisint man he couldnt take it if he killed 3 more becides they where some of his best friends who would have done any thing for him
              if (input.compare("n") == 0)
                room = 'n';

              else
                cout << "sorry, I don't understand" << endl;
             break;

             
             case 'x':
             //he made the deal becuse he was faceing serous prison time after he shot the rong guy he donst elabrate past that
             //the player has another choice here he stops fighting after this 
              if (input.compare("n") == 0)
                room = 'n';

              else
                cout << "sorry, I don't understand" << endl;
             break;
// ------------------------------badge section----------------------------------------
             case 'y':
             //he lost his badge when he shot the guy it was seposed to be a reminder of how he was seposed to serve the pepole above him self and he failed that day when he shot the wrong guy                                           
              
              if (input.compare("y") == 0)
                room = 'u';

              if (input.compare("n") == 0)
                room = 'w';

              else
                cout << "sorry, I don't understand" << endl;
             break;

//--------------------if they chose to kill the cop------------------------------------
             case 'u':
             // you tell him thats unforcanetly not good enough for the devil and you kill him  
              thedevil++;                               
              if (input.compare("n") == 0)
                room = 'n';
              else
                cout << "sorry, I don't understand" << endl;
             break;

            

//--------------------if you chose to spare the cop-----------------------
             case 'w':
             //you tell him you could try and trick the devil for him claim that hes dead he agrees and you take the badge with a bit of his blood on it as proof
              sinners++;                                 
              if (input.compare("n") == 0)
                room = 'n';

              else
                cout << "sorry, I don't understand" << endl;
             break;




//-------------------------end of badge section-----------------------------





             case 'z':
             //he says why dont you do the same 
              if (input.compare("n") == 0)
                room = 'n';

              else
                cout << "sorry, I don't understand" << endl;
             break;









            //---------go back------
            getline(cin, input);
            if (input.compare("n") == 0)
                room = 'n';

            else
                cout << "sorry, I don't understand" << endl;
            break;


        case 'd':
            //---------------------------investigate-----------------------------------
            getline(cin, input);
            if (input.compare("n") == 0)
                room = 'n';

            else
                cout << "sorry, I don't understand" << endl;
            break;     

        case 'e':
            //---------------------------give up-----------------------------------

            cout<<"i cant do this anymore..."<<endl;
              bool giveup = true;



            break;

        
        }//end switch
    } //loop  cop

    cout << "exiting cop loop, back to main game." << endl;
    return 'u'; //nothing changed
    
}

//----------------------------------endings------------------------------------
 
    }//----------------no thanks------------------- 
        if (hasWon == true && nothanks == 1) {
        cout << "ending 1 of 10" << endl;
        cout << "souless angel" << endl;
    }
     //---------------the devil-------------------
    if (hasWon == true && thedevil == 3) {
        cout << "seacret ending 2 of 10" << endl;
        cout << "the devil" << endl;
    }
     //------------ sinners----------------------
    if (hasWon == true && sinners == 3) {
        cout << "the true ending 3 of 10" << endl;
        cout << "the sinners" << endl;
    }
     //-----------the devils work---------------
    if (hasWon == true && devilswork == 1) {
        cout << "ending 4 of 10" << endl;
        cout << "the devils work" << endl;
    }
    //-----------give up---------------
    if (giveup == true) {
        cout << "ending 5 of 10" << endl;
        cout << "the souless flight" << endl;
    }
    //----------dead-------------------
    if (isDead == true) {
        cout << "YOU DIED. game over." << endl;
        cout << "ending 6 of 10" << endl;
        cout << "a broken deal" << endl;
    }

    //you only see this when game is done
    cout << endl << endl << "you seem to have reached the end of your souless flight" << endl;

}//end main
    
    



